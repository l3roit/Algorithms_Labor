#!/bin/sh -f

rand_seq 10 > listn_000010.txt
rand_seq 100 > listn_000100.txt
rand_seq 1000 > listn_001000.txt
rand_seq 10000 > listn_010000.txt
rand_seq 100000 > listn_100000.txt
rand_seq 1000000 > listn_1000000.txt


rand_seq 10 |sort -n > lists_000010.txt
rand_seq 100 |sort -n > lists_000100.txt
rand_seq 1000 |sort -n> lists_001000.txt
rand_seq 10000 |sort -n> lists_010000.txt
rand_seq 100000 |sort -n > lists_100000.txt

rand_seq 10 |sort -rn > listr_000010.txt
rand_seq 100 |sort -rn > listr_000100.txt
rand_seq 1000 |sort -rn> listr_001000.txt
rand_seq 10000 |sort -rn> listr_010000.txt
rand_seq 100000 |sort -rn > listr_100000.txt


