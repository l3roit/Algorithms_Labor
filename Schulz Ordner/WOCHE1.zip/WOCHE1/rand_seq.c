/*-----------------------------------------------------------------------

File  : rand_seq.c

Author: Stephan Schulz (schulz@eprover.org)

Contents

  Program that generates and prints a sequence of random numbers, one
  per line.

Copyright 2015 by the author.

  This code is released under the GNU General Public Licence, version
  2, or, at your choice, any later version. See the file COPYING.

Changes

<1> Fri Apr 24 21:36:17 CEST 2015
    New

-----------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAXNUM 1000
/* Random gives us numbers up to (2**31)-1 */
#define MAXRAND ((double)((1l<<31)-1))


int main(int argc, char *argv[])
{
   int count, i;
   long intrand;
   double frand;

   if(argc != 2)
   {
      fprintf(stderr, "Usage: %s <number>\n", argv[0]);
      exit(EXIT_FAILURE);
   }
   count = atoi(argv[1]);

   srandomdev();
   for(i=0; i<count; i++)
   {
      frand = drand48();
      /* Now scale to the required range */
      intrand = frand*MAXNUM;
      printf("%ld\n", intrand);
   }
   exit(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------*/
/*                        End of File                                  */
/*---------------------------------------------------------------------*/
