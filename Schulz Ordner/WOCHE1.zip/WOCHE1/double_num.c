/*-----------------------------------------------------------------------

File  : double_num.c

Author: Stephan Schulz (schulz@eprover.org)

Contents

  Program that reads and doubles integers.

Copyright 2015 by the author.

  This code is released under the GNU General Public Licence, version
  2, or, at your choice, any later version. See the file COPYING.

Changes

<1> Fri Apr 24 21:36:17 CEST 2015
    New

-----------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

#define MAXLINE  256
#define MAXITEMS 1000000


int main(int argc, char *argv[])
{
   FILE *in = stdin;
   char line[MAXLINE];

   if(argc > 2)
   {
      fprintf(stderr, "Usage: %s [<file>]\n", argv[0]);
      exit(EXIT_FAILURE);
   }
   if(argc == 2)
   {
      in = fopen(argv[1], "r");
      if(!in)
      {
         perror(argv[0]);
         exit(EXIT_FAILURE);
      }
   }
   while(fgets(line, MAXLINE, in))
   {
      printf("%lld\n", 2*atoll(line));
   }
   if(in!=stdin)
   {
      fclose(in);
   }

   exit(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------*/
/*                        End of File                                  */
/*---------------------------------------------------------------------*/
