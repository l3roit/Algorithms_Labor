/*-----------------------------------------------------------------------

  File  : reverse_str.c

  Author: Stephan Schulz (schulz@eprover.org)

  Contents

  Program that reads up to MAXITEMS strings and prints them back in
  reverse order. New "simpler" version without dynamic memory usage.

  Copyright 2018 by the author.

  This code is released under the GNU General Public Licence, version
  2, or, at your choice, any later version. See the file COPYING.

  Created: Tue May  8 16:35:10 CEST 2018

-----------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE  256
#define MAXITEMS 10000

/* I don't like 2-D-arrays, so make "Line" a separate data type */

typedef char Line[MAXLINE];

/* We define the data array as a global variable to avoid stack
 * overflow for long arrays - local variables are allocated on the
 * stack. */

Line data[MAXITEMS];

int main(int argc, char *argv[])
{
   FILE *in = stdin;
   int count, i;
   Line line;
   char* inp;


   if(argc > 2)
   {
      fprintf(stderr, "Usage: %s [<file>]\n", argv[0]);
      exit(EXIT_FAILURE);
   }
   if(argc == 2)
   {
      in = fopen(argv[1], "r");
      if(!in)
      {
         perror(argv[0]);
         exit(EXIT_FAILURE);
      }
   }
   count = 0;

   while((inp = fgets(line, MAXLINE, in)))
   {
      if(count == MAXITEMS)
      {
         fprintf(stderr, "%s: too many data items\n", argv[0]);
         exit(EXIT_FAILURE);
      }
      strcpy(data[count++], inp);
   }
   for(i=count; i; i--)
   {
      printf("%s",data[i-1]);
   }
   if(in!=stdin)
   {
      fclose(in);
   }

   exit(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------*/
/*                        End of File                                  */
/*---------------------------------------------------------------------*/
