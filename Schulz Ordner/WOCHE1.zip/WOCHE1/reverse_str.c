/*-----------------------------------------------------------------------

  File  : reverse_str.c

  Author: Stephan Schulz (schulz@eprover.org)

  Contents

  Program that reads up to MAXITEMS strings and prints them back in
  reverse order. See reverse_str2 for a version without
  malloc()/free().

  Copyright 2015, 2018 by the author.

  This code is released under the GNU General Public Licence, version
  2, or, at your choice, any later version. See the file COPYING.

  Creayed: Fri Apr 24 21:36:17 CEST 2015

-----------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE  256
#define MAXITEMS 10000


/* We define the data array as a global variable to avoid stack
 * overflow for long arrays - local variables are allocated on the
 * stack. */

char* data[MAXITEMS];

int main(int argc, char *argv[])
{
   FILE *in = stdin;
   int count, i;
   char line[MAXLINE];
   char* inp;


   if(argc > 2)
   {
      fprintf(stderr, "Usage: reverse_str [<file>]\n");
      exit(EXIT_FAILURE);
   }
   if(argc == 2)
   {
      in = fopen(argv[1], "r");
      if(!in)
      {
         perror(argv[0]);
         exit(EXIT_FAILURE);
      }
   }
   count = 0;

   while((inp = fgets(line, MAXLINE, in)))
   {
      if(count == MAXITEMS)
      {
         fprintf(stderr, "%s: too many data items\n", argv[0]);
         exit(EXIT_FAILURE);
      }
      data[count++] = strdup(inp);
   }
   for(i=count; i; i--)
   {
      printf("%s",data[i-1]);
   }
   /* Because I'm anal: free all the strings */
   for(i=0; i<count; i++)
   {
      free(data[i]);
   }

   if(in!=stdin)
   {
      fclose(in);
   }

   exit(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------*/
/*                        End of File                                  */
/*---------------------------------------------------------------------*/
