/*-----------------------------------------------------------------------

  File  : lin_list.c

Author: Stephan Schulz (schulz@eprover.org)

Contents

  Library implementing singly linked lists (of strings), and a test
  program that uses it to read strings and  print them back in normal
  or reverse order.

Copyright 2015-2017 by the author.
  This code is released under the GNU General Public Licence, version
  2, or, at your choice, any later version.

Changes

<1> Fri Apr 24 21:36:17 CEST 2015
    New

-----------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE  256


/* Data type: Linear list cell */

typedef struct lin_list
{
   char            *payload; /* User data (in this case just strings) */
   struct lin_list *next;    /* Pointer to rest of list (or NULL) */
}LinListCell, *LinList_p;

/*-----------------------------------------------------------------------
//
// Function: xmalloc()
//
//   Thin wrapper around malloc() - fail noisily (with error message)
//   if no memory is available.
//
// Global Variables: -
//
// Side Effects    : Only via malloc() or in case of error
//
/----------------------------------------------------------------------*/

void* xmalloc(size_t size)
{
   void *mem = malloc(size);
   if(!mem)
   {
      fprintf(stderr, "lin_list: Out of memory (during malloc())\n");
      exit(EXIT_FAILURE);
   }
   return mem;
}

/*-----------------------------------------------------------------------
//
// Function: xstrdup()
//
//   Thin wrapper around strdup() - fail noisily (with error message)
//   if no memory is available.
//
// Global Variables: -
//
// Side Effects    : Only via malloc() or in case of error
//
/----------------------------------------------------------------------*/

char* xstrdup(char* str)
{
   void *newstr = strdup(str);
   if(!newstr)
   {
      fprintf(stderr, "lin_list: Out of memory (during strdup())\n");
      exit(EXIT_FAILURE);
   }
   return newstr;
}


/*-----------------------------------------------------------------------
//
// Function: LinListAllocCell()
//
//   Allocate a Linear List Cell initialised with the given payload
//   string. The string is copied!
//
// Global Variables: -
//
// Side Effects    : Memory operations
//
/----------------------------------------------------------------------*/

LinList_p LinListAllocCell(char* payload)
{
   LinList_p cell = xmalloc(sizeof(LinListCell));

   cell->payload = xstrdup(payload);
   cell->next    = NULL;

   return cell;
}

/*-----------------------------------------------------------------------
//
// Function: LinListFreeCell()
//
//   Free a linear list cell, including payload, but not possible
//   sublists.
//
// Global Variables: -
//
// Side Effects    : Memory operations
//
/----------------------------------------------------------------------*/

void LinListFreeCell(LinList_p junk)
{
   free(junk->payload);
   free(junk);
}

/*-----------------------------------------------------------------------
//
// Function: LinListFree()
//
//   Free a linear list. Elegant recursive version.
//
// Global Variables: -
//
// Side Effects    : Memory operations
//
/----------------------------------------------------------------------*/

void LinListFree(LinList_p *junk)
{
   if(*junk)
   {
      LinListFree(&(*junk)->next);
      LinListFreeCell(*junk);
      *junk = NULL;
   }
}


/*-----------------------------------------------------------------------
//
// Function: LinListFree2()
//
//   Free a linear list. Iterative version.
//
// Global Variables: -
//
// Side Effects    : Memory operations
//
/----------------------------------------------------------------------*/

void LinListFree2(LinList_p *junk)
{
   LinList_p cell;

   while(*junk)
   {
      cell = (*junk)->next;  /* Save next pointer */
      LinListFreeCell(*junk);
      *junk = cell;          /* Store rest list in anchor */
   }
}



/*-----------------------------------------------------------------------
//
// Function: LinListInsertFirst()
//
//   Insert a new cell as the first cell of the existing list (which
//   may be empty). Returns new list.
//
// Global Variables: -
//
// Side Effects    : -
//
/----------------------------------------------------------------------*/

LinList_p LinListInsertFirst(LinList_p *anchor, LinList_p newcell)
{
   newcell->next = *anchor;
   *anchor = newcell;

   return newcell;
}

/*-----------------------------------------------------------------------
//
// Function: LinListExtractFirst()
//
//   Extract and return the first cell of a linear list. If the list
//   is empty, return NULL.
//
// Global Variables: -
//
// Side Effects    : -
//
/----------------------------------------------------------------------*/

LinList_p LinListExtractFirst(LinList_p *anchor)
{
   LinList_p res = *anchor;

   if(res)
   {
      *anchor = res->next;
      res->next = NULL;
   }
   return res;
}

/*-----------------------------------------------------------------------
//
// Function: LinListRevert()
//
//   Revert the list stored at *anchor.
//
// Global Variables: -
//
// Side Effects    : -
//
/----------------------------------------------------------------------*/

void LinListRevert(LinList_p *anchor)
{
   LinList_p newlist = NULL, handle;

   while(*anchor)
   {
      handle = LinListExtractFirst(anchor);
      LinListInsertFirst(&newlist, handle);
   }
   *anchor = newlist;
}


/*-----------------------------------------------------------------------
//
// Function: LinListPrint()
//
//   Print the payload of the list cells at list to out.
//
// Global Variables: -
//
// Side Effects    : Output
//
/----------------------------------------------------------------------*/

void LinListPrint(FILE* out, LinList_p list)
{
   while(list)
   {
      fprintf(out, "%s", list->payload);
      list = list->next;
   }
}



/*-----------------------------------------------------------------------
//
// Function: main()
//
//   Open file (or use stdin), read and store input, process lists
//
// Global Variables: -
//
// Side Effects    : I/O
//
/----------------------------------------------------------------------*/

int main(int argc, char *argv[])
{
   FILE *in = stdin;
   char line[MAXLINE];
   LinList_p l1 = NULL, handle;
   char* inp;

   if(argc > 2)
   {
      fprintf(stderr, "Usage: %s [<file>]\n", argv[0]);
      exit(EXIT_FAILURE);
   }
   if(argc == 2)
   {
      in = fopen(argv[1], "r");
      if(!in)
      {
         perror(argv[0]);
         exit(EXIT_FAILURE);
      }
   }
   while((inp = fgets(line, MAXLINE, in)))
   {
      handle = LinListAllocCell(line);
      LinListInsertFirst(&l1, handle);
   }

   fprintf(stdout, "Reverse order\n=============\n");
   LinListPrint(stdout, l1);

   LinListRevert(&l1);

   fprintf(stdout, "Original order\n==============\n");
   LinListPrint(stdout, l1);

   LinListFree2(&l1);

   if(in!=stdin)
   {
      fclose(in);
   }

   exit(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------*/
/*                        End of File                                  */
/*---------------------------------------------------------------------*/
